package com.AgenceLocation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenceLocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgenceLocationApplication.class, args);
	}

}
