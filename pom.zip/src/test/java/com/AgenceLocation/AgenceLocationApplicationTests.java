package com.AgenceLocation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenceLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
